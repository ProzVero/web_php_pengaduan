<?php

$host = "sql304.epizy.com";

$user = "epiz_30566725";

$pass = "xSmpWtgLff";

$db = "epiz_30566725_pengaduan";

$konek = mysqli_connect($host, $user, $pass, $db) or die ('gagal koneksi ke database');


?>

