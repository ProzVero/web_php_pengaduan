<div class="well well-sm col-md-12">
	<footer class="footer">
		<p><?php echo "Copyright © " . (int)date('Y') . " Polsek Wara Utara"; ?></p>
	</footer>	
</div>
