<!DOCTYPE html>

<html>

<head>

  <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Tentang</title>

    <link rel="icon" href="asset/img/favicon.png" type="image/x-icon" />

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/navbar.css" rel="stylesheet">

    <link href="asset/indexs.css" rel="stylesheet">

</head>

<body style="background-image: url('asset/img/polri.jpg'); height: 100%; background-position: center; background-repeat: no-repeat; background-size: cover;">

  <div>

    <?php include "navbar.php"; ?>

  </div>
  <div class="container">

      <div class="well well-sm col-md-12">

        <br>

          <div class="panel col-md-12">

            <table>

              <tr>

                <td>

                  <div style="text-align: justify;">

                  <div style="text-align: center;">

                  <table style="border-collapse: collapse; border-spacing: 0px; box-sizing: border-box; color: #333333; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;"><tbody style="box-sizing: border-box;">

                  <tr style="box-sizing: border-box;"><td style="box-sizing: border-box; padding: 0px;"><div style="box-sizing: border-box; text-align: justify;">

                  <div style="box-sizing: border-box; text-align: center;">

                  <span style="box-sizing: border-box; font-size: medium;"><span style="box-sizing: border-box; font-weight: 700;"><br /></span></span>

                  <span style="box-sizing: border-box; font-size: medium;"><span style="box-sizing: border-box; font-weight: 700;">PROFIL POLSEK WARA UTARA</span></span></div><div class="row"><br>

              <p align="center">

            <div class="col-xs-6 col-md-12">

          <a href="#" class="thumbnail">

          Pimpinan KAPOLSEK 

          PATOBUN,S.PD

      </a>

    </div>

  </p>

</div>

 

<br style="box-sizing: border-box;" /></div>

</td></tr>

<tr style="box-sizing: border-box;"><td style="box-sizing: border-box; padding: 0px;"><div style="box-sizing: border-box; text-align: justify;">

<div class="MsoNormal" style="box-sizing: border-box; line-height: 28px;">

<span style="box-sizing: border-box; font-weight: 700;"><span style="box-sizing: border-box; font-family: &quot;times new roman&quot; , serif;"><span style="box-sizing: border-box; font-size: large;">Visi</span></span></span><br />

<span style="font-family: georgia, 'times new roman', serif; font-size: 12pt; line-height: 32px; text-align: left;">Mewujudkan&nbsp; keamanan dan ketertiban masyarakat melalui kemitraan dan meningkatkan kepercayaan masyarakat serta upaya peningkatan pelayanan dan perlindungan terhadap masyarakat.</span></div>

<div class="MsoNormal" style="box-sizing: border-box; line-height: 28px; margin-left: 99.25pt;">

<div style="text-align: left;">

<br style="box-sizing: border-box;" /></div>

</div>

<div class="MsoNormal" style="box-sizing: border-box; line-height: 28px;">

<span style="box-sizing: border-box; font-weight: 700;"><span style="box-sizing: border-box; font-family: &quot;times new roman&quot; , serif;"><span style="box-sizing: border-box; font-size: large;">Misi</span><span style="box-sizing: border-box; font-size: 12pt;"><o:p style="box-sizing: border-box;"></o:p></span></span></span></div>

<div class="MsoNormal" style="box-sizing: border-box; line-height: 28px;">

<div style="line-height: 28px;">

</div>

<ul>

<li style="line-height: 28px;"><span style="font-family: &quot;times new roman&quot; , serif; font-size: 12pt; line-height: 32px;">Memberikan perlindungan, pengayoman dan pelayanan terhadap masyarakat sehingga merasa aman dan tentram.</span></li>

<li style="line-height: 28px;"><span style="font-family: &quot;times new roman&quot; , serif; font-size: 12pt; line-height: 32px;">Memberikan bimbingan kepada masyarakat melalui upaya preemtif dan preventive yang dapat meningkatkan kesadaran dan kepatuhan hukum serta partisipasi dalam babinkamtibnas.</span></li>

<li><span style="font-family: &quot;times new roman&quot; , serif;"><span style="font-size: 16px; line-height: 32px;">Menegakkan hukum secara professional dan proporsional dengan menjunjung tinggi supremasi hukum dan hak asasi manusia untuk mewujudkan adanya kepastian hukum dan rasa keadilan.</span></span></li>

<li><span style="font-family: &quot;times new roman&quot; , serif;"><span style="font-size: 16px; line-height: 32px;">Memelihara kamtibnas dengan tetap menjunjung tinggi norma-norma yang berlaku dalam kehidupan masyarakat.</span></span></li>

<li><span style="font-family: &quot;times new roman&quot; , serif;"><span style="font-size: 16px; line-height: 32px;">Membina sumber daya manusia polri yang professional patuh hukum dan senantiasa berprilaku terpuji.</span></span></li>

</ul>

<div style="line-height: 28px;">

</div>

</div>

</div>

</td></tr>

</tbody></table>

</div>

</div>

</td>

</tr>

</table>

  </div>

    </div>  

  

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

    <script src="js/bootstrap.min.js"></script>   

  </div>  

</body>

</html>

