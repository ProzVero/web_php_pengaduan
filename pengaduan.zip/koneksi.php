<?php

$host = "localhost";

$user = "root";

$pass = "";

$db = "db_pengaduan";

$konek = mysqli_connect($host, $user, $pass, $db) or die("gagal koneksi ke database");

//mysqli_select_db($db);

//$db = mysqli_connect($host, $user, $pass, $database) or die("gagal koneksi ke database");

?>

