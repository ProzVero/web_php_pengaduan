<div class="navbar-default sidebar" role="navigation">
  <div class="sidebar-nav navbar-collapse">
    <ul class="nav" id="side-menu">
      <li class="sidebar-search"><p></p>
      <p align="center">
        <img src="asset/img/l.gif" alt="" width="20%">
        <img src="asset/img/l.gif" alt="" width="20%">
        <img src="asset/img/l.gif" alt="" width="20%">
        <img src="asset/img/l.gif" alt="" width="20%">
      </p>
      </li>
      <li><a href="admin.php"><i class="fa fa-home fa-fw"></i> Admin Page</a></li>
      <li><a href="tabel_aduan.php"><i class="fa fa-edit fa-fw"></i> Tabel Aduan</a></li>
      
      <li><a href="tabel_korban.php"><i class="fa fa-edit fa-fw"></i> Tabel Korban</a></li>
      <li><a href="tabel_pelaku.php"><i class="fa fa-edit fa-fw"></i> Tabel Pelaku</a></li>
      <li><a href="tabel_pelapor.php"><i class="fa fa-edit fa-fw"></i> Tabel Pelapor</a></li> 
      <li><a href="tabel_himbauan.php"><i class="fa fa-edit fa-fw"></i> Tabel Himbauan</a></li> 
      <li><a href="input_himbauan.php"><i class="fa fa-edit fa-fw"></i> Input Himbauan</a></li> 
    </ul>
  </div>
</div>
