    <div class="well well-sm col-md-12">
    <p align="right"><a href="logoutuser.php"><span class="glyphicon glyphicon-log-out"> Logout</span></a></p>
    <caption><p align="center"><h4><b>Slide Contents</b></h4></p></caption>
      <div class="btn-group" role="group">
        <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         User Links
          <span class="caret"></span>
        </button>
        <ul class="dropdown-menu">
          <li><a href="user.php">User Profile</a></li>
          <li><a href="logoutuser.php">Keluar</a></li>
        </ul>
      </div>
      <div class="btn-group" role="group">
        <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Forms List
          <span class="caret"></span>
        </button>
        <ul class="dropdown-menu">
          <li><a href="aduan.php"> Pengaduan Online</a></li>
          <li><a href="aduan.php"> Form Aduan</a></li>
          <li><a href="korban.php"> Form Korban</a></li>
          <li><a href="pelaku.php"> Form Pelaku</a></li>
        </ul>
      </div>
      <hr>
      <caption><b>Panel</b></caption>
      <div class="panel panel-info col-md-12">
        <p>Anda berada dihalaman user, dihalaman ini anda bisa melaporkan tentang tindakan 
        kriminalitas yang terjadi disekitar anda. Terima Kasih.</p>
      </div>
    </div>       